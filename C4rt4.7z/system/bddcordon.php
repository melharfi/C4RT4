<?php
$server="localhost";
$Auser="C4RT4_user";
$Apass="123456789";
$bdd="C4RT4_bdd";
////////// connexcion a la bdd\\\\\\
$db = mysql_connect($server,$Auser,$Apass);
mysql_select_db($bdd,$db);
?>